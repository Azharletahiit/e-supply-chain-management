<div class="content-wrapper">
    <div class="content-heading">
       <div>Setting<small>Backup Databases</small></div>
    </div>
    <div class="row">
        <div class="col-xl-12">
            <div class="card card-default">
              <div class="card-header">
                 <div class="card-title">Backup Databases</div>
              </div>
              <div class="card-body">
                    <div class="alert alert-info">
                         <p class="mb-0">Jangan Lupa untuk Selalu Melakukan Backup Database setiap Harinya!</p>
                    </div>
                    <a class="btn btn-labeled btn-success mb-2 text-white" href="myphp-backup" target="_blank">
                      <span class="btn-label"><i class="fa fa-download"></i></span>BackUp Database
                    </a>
              </div>
            </div>
        </div>
    </div>
 </div>