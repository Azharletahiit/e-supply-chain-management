-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 26, 2023 at 12:33 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `galon`
--

-- --------------------------------------------------------

--
-- Table structure for table `air_masuk`
--

CREATE TABLE `air_masuk` (
  `id_masuk` int(11) NOT NULL,
  `tanggal_masuk` varchar(200) NOT NULL,
  `jumlah_masuk` int(11) NOT NULL,
  `id_galon` int(11) NOT NULL,
  `id_supplier` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `air_masuk`
--

INSERT INTO `air_masuk` (`id_masuk`, `tanggal_masuk`, `jumlah_masuk`, `id_galon`, `id_supplier`) VALUES
(1, '2019-11-25', 50, 2, 0),
(2, '2020-02-06', 100, 2, 0),
(3, '2023-01-09', 122, 2, 0),
(4, '2023-01-09', 1000, 6, 0),
(5, '2023-01-09', 2000, 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `galon`
--

CREATE TABLE `galon` (
  `id_galon` int(11) NOT NULL,
  `jenis` varchar(200) NOT NULL,
  `harga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `galon`
--

INSERT INTO `galon` (`id_galon`, `jenis`, `harga`) VALUES
(2, 'Air Mineral', 6000),
(6, 'Air + Galon', 50000),
(7, 'Air RO', 8000);

-- --------------------------------------------------------

--
-- Table structure for table `galon_masuk`
--

CREATE TABLE `galon_masuk` (
  `id_masuk` int(11) NOT NULL,
  `tanggal_masuk` varchar(200) NOT NULL,
  `jumlah_masuk` int(11) NOT NULL,
  `jenis` varchar(11) NOT NULL,
  `id_supplier` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `galon_masuk`
--

INSERT INTO `galon_masuk` (`id_masuk`, `tanggal_masuk`, `jumlah_masuk`, `jenis`, `id_supplier`) VALUES
(8, '2023-01-16', 2000, 'Air', 1),
(9, '2023-01-17', 50, 'Galon', 3),
(10, '2023-01-23', 2000, 'Air', 1);

-- --------------------------------------------------------

--
-- Table structure for table `konsumen`
--

CREATE TABLE `konsumen` (
  `id` int(11) NOT NULL,
  `telp` varchar(20) NOT NULL,
  `nama_konsumen` varchar(200) NOT NULL,
  `tgl_masuk` varchar(100) NOT NULL,
  `keterangan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `konsumen`
--

INSERT INTO `konsumen` (`id`, `telp`, `nama_konsumen`, `tgl_masuk`, `keterangan`) VALUES
(2, '08114700155', 'RM. Padang', '2019-11-01', 'Rumah Makan Kota'),
(3, '-', 'Umum', '2020-02-07', 'Konsumen Umum'),
(7, '082292540589', 'Azhar', '2023-01-20', '-'),
(8, '082288648722', 'Azhar', '2023-01-23', '-');

-- --------------------------------------------------------

--
-- Table structure for table `pengeluaran`
--

CREATE TABLE `pengeluaran` (
  `id_pengeluaran` int(11) NOT NULL,
  `jenis` varchar(200) NOT NULL,
  `tanggal` varchar(200) NOT NULL,
  `total` int(11) NOT NULL,
  `keterangan` text NOT NULL,
  `id_user` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pengeluaran`
--

INSERT INTO `pengeluaran` (`id_pengeluaran`, `jenis`, `tanggal`, `total`, `keterangan`, `id_user`) VALUES
(1, 'Gaji Pegawai', '26-11-2019', 150000, '', 4),
(2, 'Operasional', '06-02-2020', 100000, 'adsa', 1),
(3, 'Air', '09-01-2023', 100000, 'Pembelian Air', 1),
(5, 'Operasional', '2023-01-19', 200000, 'Token Listrik', 1);

-- --------------------------------------------------------

--
-- Table structure for table `penjualan`
--

CREATE TABLE `penjualan` (
  `id_penjualan` int(11) NOT NULL,
  `tanggal` varchar(200) NOT NULL,
  `qty` int(11) NOT NULL,
  `id_galon` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_konsumen` varchar(100) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `penjualan`
--

INSERT INTO `penjualan` (`id_penjualan`, `tanggal`, `qty`, `id_galon`, `id_user`, `id_konsumen`, `status`) VALUES
(9, '09-01-2023', 1, 6, 1, '2', 1),
(10, '09-01-2023', 1, 6, 1, '2', 1),
(11, '09-01-2023', 1, 6, 1, '2', 1),
(12, '09-01-2023', 3, 2, 1, '2', 1),
(13, '17-01-2023', 2, 2, 1, '2', 1),
(14, '17-01-2023', 2, 2, 1, '2', 1),
(15, '17-01-2023', 3, 2, 1, '2', 1),
(16, '17-01-2023', 3, 6, 1, '2', 1),
(17, '20-01-2023', 2, 6, 1, '2', 1),
(18, '20-01-2023', 4, 2, 1, '7', 1),
(19, '23-01-2023', 2, 6, 1, '8', 1);

-- --------------------------------------------------------

--
-- Table structure for table `stok`
--

CREATE TABLE `stok` (
  `id` int(11) NOT NULL,
  `jenis` varchar(200) NOT NULL,
  `stok` int(11) NOT NULL,
  `setting` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stok`
--

INSERT INTO `stok` (`id`, `jenis`, `stok`, `setting`) VALUES
(1, 'Air', 3945, 12),
(2, 'Galon', 43, 0);

-- --------------------------------------------------------

--
-- Table structure for table `suplier`
--

CREATE TABLE `suplier` (
  `id` int(11) NOT NULL,
  `nama` varchar(200) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `telp` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `suplier`
--

INSERT INTO `suplier` (`id`, `nama`, `alamat`, `telp`) VALUES
(1, 'CV Jaya Abadi', 'Air Besar, Ambon', '081321'),
(3, 'CV Galon Sejahtera', 'Ambon', '09123123');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `nama` varchar(200) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `level` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `nama`, `username`, `password`, `level`) VALUES
(1, 'Admin Aidil', 'admin', '21232f297a57a5a743894a0e4a801fc3', 'Admin'),
(4, 'Kasir', 'kasir', 'c7911af3adbd12a035b289556d96470a', 'Kasir');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `air_masuk`
--
ALTER TABLE `air_masuk`
  ADD PRIMARY KEY (`id_masuk`);

--
-- Indexes for table `galon`
--
ALTER TABLE `galon`
  ADD PRIMARY KEY (`id_galon`);

--
-- Indexes for table `galon_masuk`
--
ALTER TABLE `galon_masuk`
  ADD PRIMARY KEY (`id_masuk`);

--
-- Indexes for table `konsumen`
--
ALTER TABLE `konsumen`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pengeluaran`
--
ALTER TABLE `pengeluaran`
  ADD PRIMARY KEY (`id_pengeluaran`);

--
-- Indexes for table `penjualan`
--
ALTER TABLE `penjualan`
  ADD PRIMARY KEY (`id_penjualan`);

--
-- Indexes for table `stok`
--
ALTER TABLE `stok`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `suplier`
--
ALTER TABLE `suplier`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `air_masuk`
--
ALTER TABLE `air_masuk`
  MODIFY `id_masuk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `galon`
--
ALTER TABLE `galon`
  MODIFY `id_galon` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `galon_masuk`
--
ALTER TABLE `galon_masuk`
  MODIFY `id_masuk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `konsumen`
--
ALTER TABLE `konsumen`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `pengeluaran`
--
ALTER TABLE `pengeluaran`
  MODIFY `id_pengeluaran` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `penjualan`
--
ALTER TABLE `penjualan`
  MODIFY `id_penjualan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `stok`
--
ALTER TABLE `stok`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `suplier`
--
ALTER TABLE `suplier`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
